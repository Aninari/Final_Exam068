<html>
<head>
    <title>เปลี่ยนสีพื้นหลัง</title>
    <style>
        body {
            transition: background-color 0.5s ease;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        button {
            padding: 10px 20px;
            margin: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>

<h2>กรุณาเลือกสีที่ต้องการ</h2>

<button onclick="changeColor('green')">เขียว</button>
<button onclick="changeColor('orange')">ส้ม</button>
<button onclick="changeColor('purple')">ม่วง</button>
<button onclick="changeColor('')">Clear</button>

<script>
function changeColor(color) {
    if(color) {
        document.body.style.backgroundColor = color;
    } else {
        document.body.style.backgroundColor = ''; 
    }
}
</script>

</body>
</html>
<html>
<head>
    <title>FizzBuzz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        input[type=number] {
            width: 80px;
            padding: 5px;
            font-size: 16px;
        }
        button {
            padding: 8px 12px;
            font-size: 16px;
            cursor: pointer;
            margin-left: 5px;
        }
        #result {
            margin-top: 15px;
            font-weight: bold;
            font-size: 18px;
            color: blue;
        }
        #error {
            margin-top: 15px;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

<h2>โปรแกรม FizzBuzz</h2>

<form method="post">
    ใส่เลข 1–100: <input type="number" name="num" min="1" max="100" required>
    <button type="submit">ตรวจสอบ</button>
</form>

<?php
if (isset($_POST['num'])) {
    $num = $_POST['num'];

    if ($num < 1 || $num > 100) {
        echo "<div id='error'>กรุณาใส่เลขระหว่าง 1 ถึง 100</div>";
    } else {
        $output = '';

        if ($num % 3 == 0 && $num % 5 == 0) {
            $output = 'FizzBuzz';
        } elseif ($num % 3 == 0) {
            $output = 'Fizz';
        } elseif ($num % 5 == 0) {
            $output = 'Buzz';
        } else {
            $output = $num;
        }

        echo "<div id='result'>ผลลัพธ์: $output</div>";
    }
}
?>

</body>
</html>
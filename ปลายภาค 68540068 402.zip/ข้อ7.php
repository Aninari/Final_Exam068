<html>
<head>
    <title>แปลงเวลา</title>
</head>
<body>

<form method="post">
    ใส่เวลา (hh:mm:ss): 
    <input type="text" name="time" placeholder="เช่น 12:30:45" required>
    <button type="submit">แปลง</button>
</form>

<?php
if (isset($_POST['time'])) {
    $time = trim($_POST['time']); // ตัดช่องว่างรอบๆ

    // แยกชั่วโมง นาที วินาที
    $parts = explode(":", $time);

    if (count($parts) === 3) {
        $hh = $parts[0];
        $mm = $parts[1];
        $ss = $parts[2];

        echo "<h3>{$hh} ชั่วโมง {$mm} นาที {$ss} วินาที</h3>";
    } else {
        echo "<p style='color:red;'>รูปแบบเวลาไม่ถูกต้อง กรุณาใส่ hh:mm:ss</p>";
    }
}
?>

</body>
</html>